/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.lambdaplay;

public class SimplePrinter
implements Runnable {

  public void run() {
    System.out.println("SimplePrinter.run");
  }
}