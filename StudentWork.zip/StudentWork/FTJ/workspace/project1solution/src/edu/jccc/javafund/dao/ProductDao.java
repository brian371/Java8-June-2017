package edu.jccc.javafund.dao;

import java.util.ArrayList;

import edu.jccc.javafund.domain.Product;

public interface ProductDao {

	default void foo() {
		System.out.println("foo!");
	}
	
	/* (non-Javadoc)
	 * @see edu.ku.train.manager.ProductManager#getProducts()
	 */
	ArrayList<Product> getProducts(); // end getProducts

	/* (non-Javadoc)
	 * @see edu.ku.train.manager.ProductManager#add(edu.ku.train.model.Product)
	 */
	void add(Product p); // end add

	/*
	 * finds a product given a model number
	 */
	/* (non-Javadoc)
	 * @see edu.ku.train.manager.ProductManager#findProductByModelNumber(int)
	 */
	Product findProductByModelNumber(int modelNumber); // end findProductByModelNumber

	/* (non-Javadoc)
	 * @see edu.ku.train.manager.ProductManager#delete(int)
	 */
	boolean delete(int modelNumber);

}