package edu.jccc.javafund.dao;

import java.util.ArrayList;

import edu.jccc.javafund.domain.Product;

public class MockProductDaoImpl implements ProductDao {

	@Override
	public ArrayList<Product> getProducts() {
		ArrayList<Product> products = new ArrayList<Product>();
		products.add(new Product(10000, 19.99, "Hammer"));
		products.add(new Product(10001, 3.99, "Screwdriver"));
		products.add(new Product(10003, 1.99, "Pliers"));
		return products;
	}

	@Override
	public void add(Product p) {
		// TODO Auto-generated method stub

	}

	@Override
	public Product findProductByModelNumber(int modelNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(int modelNumber) {
		// TODO Auto-generated method stub
		return false;
	}

}
