
public class PersonalInfo {

	public static void main(String[] args) {
		// sysout ctrl-space
		System.out.println("Brian\tPeterson\n");
		System.out.println("17565 W 161st ST");
		System.out.println("\"Olathe\", KS 66062");
	}

}
