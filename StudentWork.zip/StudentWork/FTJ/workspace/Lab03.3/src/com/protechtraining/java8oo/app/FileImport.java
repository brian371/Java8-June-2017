package com.protechtraining.java8oo.app;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.protechtraining.java8oo.model.MusicItem;

public class FileImport {
	

	public static void main(String[] args)  {
		 final String INPUT_FILE = "items.txt";
		 
		System.out.println("Opening file..");
		// auto_close feature in Java 7
		 try (BufferedReader reader = new BufferedReader(
					new FileReader(INPUT_FILE))) {
			System.out.println("File opened...");
			String line;
			List<MusicItem> itemList = new ArrayList<MusicItem>();
			int lineNum = 0;
			while ((line = reader.readLine()) != null) {
				lineNum++;
				System.out.println("processing" + line);
				String[] parts = line.split(",");
				if (parts.length != 4) {
					System.out.println("Invalid line, not 4 parts, on " +
						"line " + lineNum);
					continue;
				}
				MusicItem item = new MusicItem();
				try {
					item.setItemId(Long.parseLong(parts[0]));
				} catch (NumberFormatException e) {
					System.out.println("Invalid itemNo on line " + lineNum);
					// log this
					continue;  // skips to the next line (while loop)
				}
				item.setTitle(parts[1]);
				item.setArtist(parts[2]);
				item.setPrice(Double.parseDouble(parts[3]));
				
				itemList.add(item);
			} // end while
			
			// display the items
			System.out.println("\nHere are the loaded items...");
			for (MusicItem item : itemList) {
				System.out.println(item);
			}
		} catch (FileNotFoundException e) {
			// the code that handles the exception
			System.out.println("Sorry, " + INPUT_FILE + " was not found...");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Problem reading from: " + INPUT_FILE + ".");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("something bad has happend...");
		} finally {
			// finally blocks always execute, good or bad...
//			try {
//				if (reader != null) reader.close();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
		}
	}
}
