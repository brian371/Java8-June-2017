package com.protechtraining.java8oo.model;

/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2004-13 LearningPatterns Inc.
 */

/*
 * Lab - Writing a Class Definition
 * 
 * The Television class.  Right now it only has data.
 */

public class Television {
	// INSTANCE VARIABLES
	private  String brand = "RCA"; // the brand name (with initializer)
	private int volume; // the volume (with no initializer)
	
	public static final int MIN_VOLUME = 0;
	public static final int MAX_VOLUME = 100;
	
	public Television() {
		this("RCA", 10);
	}

	// constructor
	public Television(String brand, int volume) {
		this.brand = brand;
		this.volume = volume;
	}

	// ACCESSOR METHODS
	public String getBrand() {
		return brand;
	}

	public int getVolume() {
		return volume;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public void setVolume(int volume) {
		if (volume < MIN_VOLUME) {
			this.volume = MIN_VOLUME;
		} else if (volume > MAX_VOLUME) {
			this.volume = MAX_VOLUME;
		} else {
			this.volume = volume;
		}
	}

	@Override
	public String toString() {

		return "Television [brand=" + brand + ", volume=" + volume + "]";
	}

}
