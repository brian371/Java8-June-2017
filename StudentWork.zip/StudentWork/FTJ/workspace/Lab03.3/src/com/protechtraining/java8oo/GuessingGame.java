package com.protechtraining.java8oo;

import java.util.Random;

import com.protech.io.ConsoleHelper;

public class GuessingGame {
	public static void main(String[] args) {
		Random randGenerator = new Random();
		int randomNumber = randGenerator.nextInt(100) + 1;
		System.out.println("randomNumber " + randomNumber);
		
		int guess = ConsoleHelper.readInt("Enter guess (1 to 100): ");
		while (guess != randomNumber) {
			if (guess > randomNumber) {
				System.out.println("Too high!");
			} else if (guess < randomNumber) {
				System.out.println("Too low!");
			} 
			guess = ConsoleHelper.readInt("Enter guess (1 to 100): ");
		} // end while
		
		System.out.println("Correct.");
	} // main
} // end class
