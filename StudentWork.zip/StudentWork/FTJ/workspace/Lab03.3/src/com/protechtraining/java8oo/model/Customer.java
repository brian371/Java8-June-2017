package com.protechtraining.java8oo.model;

public class Customer {
	private int customerNum;
	private String firstName;
	private String lastName;
	
	// This is composition (has-a relationship).  We are
	// saying that the Customer has a checking and savings 
	// account inside of it.
	private Account savings;
	private Account checking;
	
	public Customer() {
		super();
	}
	
	public Account getSavings() {
		return savings;
	}


	public void setSavings(Account savings) {
		this.savings = savings;
	}


	public Account getChecking() {
		return checking;
	}


	public void setChecking(Account checking) {
		this.checking = checking;
	}


	public int getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(int customerNum) {
		this.customerNum = customerNum;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	// show example of delegation
	public void transferFromSavings(double amount) {
		// delegation is the process of using a composed (inner object)
		// to get a job done
		savings.withdraw(amount);// TODO: need to check if enough funds.
		checking.deposit(amount); 
		
	}
	

	@Override
	public String toString() {
		return "Customer [customerNum=" + customerNum + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", savings=" + savings + ", checking=" + checking + "]";
	}
	
	
	
	
}
