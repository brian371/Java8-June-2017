package com.protechtraining.java8oo;

public class PrimitiveDateTypes {

	public static void main(String[] args) {
		// in Java, there are primitives and objects.
		
		int numberOfStudents = 6;
		///numberOfStudents.xxxx  int is an primitive, no methods
		long nationDebt = 19000000000000L;
		
		double cost = 99.99; // double precision floating point
		//float msrp = 129.99f; // single precision floating point
		
		// this is casting a double into an int
		int iCost = (int) cost;
		System.out.println("iCost is " + iCost);
		
		String sCost = Double.toString(cost);
		
		boolean done = false;
		char grade = 'C';
		
		// String is a class, so you use a capital S
		String name = "Bob Smith";

	}

}
