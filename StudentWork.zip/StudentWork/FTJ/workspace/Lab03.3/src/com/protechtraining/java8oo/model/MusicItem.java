package com.protechtraining.java8oo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ITEM")
public class MusicItem {
	@Id 
	@Column(name="item_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long itemId;
	
	private String title;
	private String artist;
	private double price;

	public MusicItem() {
		super();
	}
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", title=" + title + ", artist=" + artist + ", price=" + price + "]";
	}

}
