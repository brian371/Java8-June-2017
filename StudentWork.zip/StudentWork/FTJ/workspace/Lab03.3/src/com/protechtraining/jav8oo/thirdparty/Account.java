package com.protechtraining.jav8oo.thirdparty;

public class Account {

}
