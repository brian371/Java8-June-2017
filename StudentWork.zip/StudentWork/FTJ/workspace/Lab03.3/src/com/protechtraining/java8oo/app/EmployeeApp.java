package com.protechtraining.java8oo.app;

import com.protechtraining.java8oo.model.Employee;
import com.protechtraining.java8oo.model.FullTimeEmployee;

public class EmployeeApp {
	public static void main(String[] args) {
		Employee emp1 = new FullTimeEmployee();
		Employee emp2 = new FullTimeEmployee();
		
		emp1.setEmployeeNum(10000);
		emp1.setFirstName("Brian");
		emp1.setLastName("Peterson");
		emp1.setDepartment("Training");
		
		emp2.setEmployeeNum(10001);
		emp2.setFirstName("Sue");
		emp2.setLastName("Jones");
		emp2.setDepartment("IT");
		//emp2.employeeNum = 8383;
		
		System.out.println(emp2.getFirstName() + " has empNo " +
				emp2.getEmployeeNum());
		
		System.out.println(emp1.toString());
		System.out.println(emp2);
	}
}
