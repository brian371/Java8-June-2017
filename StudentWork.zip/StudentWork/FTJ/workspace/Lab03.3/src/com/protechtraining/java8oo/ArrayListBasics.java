package com.protechtraining.java8oo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.protechtraining.java8oo.model.Account;

public class ArrayListBasics {
	public static void main(String[] args) {
		List<String> names = new ArrayList<String>(1000); // 1000 capacity
		names.add("Bob");
//		names.add(1);  // not allowed.  Only can add string objects
//		names.add(new Account()); // ditto.
		names.add("Sue");
		names.add("Michael");
		names.add("George");
		
		Collections.sort(names);
		System.out.println("Max names is " + Collections.max(names));
		
		
		System.out.println("There are " + names.size() + " names.");
		
		// print out a single names
		System.out.println("The first name is " + names.get(0));
		names.remove("Sue");
		
		// print out all the names
		System.out.println("Displaying all the names");
		for (String name : names) {
			System.out.println(name);
		}// end for
		
		// You can create a list of user defined objects
		List<Account> accounts = new ArrayList<Account>();
		Account acct2 = new Account(864.0, 8332322);
		accounts.add(new Account(1000.0, 837837));
		accounts.add(acct2);
		accounts.add(new Account(2000., 810083478));
		accounts.remove(acct2); // 2nd account
		
		for (Account a : accounts) {
			System.out.println(a.toString());
		}
		
		List<Integer> scores = new ArrayList<Integer>();
		scores.add(87);  // 87 auto-boxed into an new Integer(87)
		
		
		
	}
}
