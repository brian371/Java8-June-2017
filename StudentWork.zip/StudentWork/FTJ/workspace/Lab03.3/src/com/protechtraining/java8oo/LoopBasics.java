package com.protechtraining.java8oo;

public class LoopBasics {
	public static void main(String[] args) {
		int i = 1;
		while (i <= 10) {
			System.out.println("i is " + i);
			//i = i + 1;
			i++;
		}
		
		for (int j = 1; j <= 10; j++) {
			if (j == 5) {
				//break; // break you out of the inner most loop
				continue; // continue to next iteration of the loop
			}
			System.out.println("j is " + j);
		} // end for
		System.out.println("After for loop");
	}
}
