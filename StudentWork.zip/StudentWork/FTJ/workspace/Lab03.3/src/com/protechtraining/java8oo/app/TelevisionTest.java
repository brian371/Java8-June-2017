package com.protechtraining.java8oo.app;
/*
 
* This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2004-13 LearningPatterns Inc.
 */

import com.protechtraining.java8oo.model.Television;

/*
 * Lab - Writing a Class Definition
 *
 * This class is the main class, i.e., where the application starts.
 *
 * It instantiates two Television objects, sets the instance variables,
 * and uses System.out.println to display them.
 */

class TelevisionTest {
	
	private void varMethod(String... names) {
		for (String cur : names) { // Iterate over it
			System.out.println(cur);
		}
		System.out.println(names.length); // Treat like array
	}
	public static void main(String[] args) {
		// instantiate two Televisions
		Television firstTV = new Television();
		Television secondTV = new Television("Hitachi", 17);

		// assign values to the brand using direct access
		// This will not be legal in next lab
		System.out.println(firstTV.toString());
		firstTV.setBrand("Hitachi");
		firstTV.setVolume(110);

		// display the values using System.out.println and string concantenation
//		System.out.println("Television: brand=" + firstTV.getBrand()
//			+ ", volume=" + firstTV.getVolume());
//		System.out.println("Television: brand=" + secondTV.getBrand()
//			+ ", volume=" + secondTV.getVolume());
		
		System.out.println(firstTV.toString());
		System.out.println(secondTV.toString());
		
		// start Lab 6.1 here
		// Create an array of Television references, based on ]
		// main's String[] args
		System.out.println("Reading tvs from run configurations");
		Television[] tvs = new Television[args.length];
		for (int i = 0; i < args.length; i++) {
			String brand = args[i];
			int volume = 5;
			tvs[i] = new Television();
			tvs[i].setBrand(brand);
			tvs[i].setVolume(volume);
		}// end for
		
		// another for loop to display the tvs (toString())
		for (Television tv : tvs) {
			System.out.println(tv.toString());
		} // end for
		
	} // end main
} // end class
