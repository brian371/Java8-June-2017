package com.protechtraining.java8oo;

import java.util.HashMap;
import java.util.Map;

public class HashMapBasics {
	public static void main(String[] args) {
		Map<String, String> states =
				new HashMap<String, String>();
		
		states.put("KS", "Kansas");
		states.put("OH", "Ohio");
		states.put("PA", "Pennsylvania");
		
		System.out.println("PA is " + states.get("PA"));
	}
}
