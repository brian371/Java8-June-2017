package com.protechtraining.java8oo.app;

import com.protechtraining.java8oo.model.Account;
import com.protechtraining.java8oo.model.CheckingAccount;
import com.protechtraining.java8oo.model.SavingsAccount;

public class AccountApp {

	public static void main(String[] args) {
		SavingsAccount.setInterestRate(0.01); // 1%	
		
		com.protechtraining.jav8oo.thirdparty.Account thirdPartyAccount =
				new com.protechtraining.jav8oo.thirdparty.Account();
		
		// polymorphism happens when a subclass object is assigned
		// to a superclass reference..
		Account acct1 = new SavingsAccount();
		SavingsAccount acct2 = new SavingsAccount(300.0, 100045);
		Account acct3 = acct2;
		Account acct4 = null;  // acct4 doesn't reference an object
		// be careful with nulls...
		//acct4.setAccountNo(83833);
		
		final int MAX_STUDENTS = 10;
	
		
		// using the set method to indirectly assign the value
		acct1.setAccountNo(37376);
		acct1.deposit(200.00);
//		System.out.println("acct1 interest is " 
//				+ acct1.calculateInterest());
		
		// Here, toString() is being called polymorphically...
		System.out.println("account 1 = " + acct1.toString());
		
		//acct2.setAccountNo(100045); // direct assignment is NOT common.
		acct2.deposit(300.0);
		acct2.deposit(100.0, "ATM Deposit");
		System.out.println("acct2 interest is " 
				+ acct2.calculateInterest());
		
		acct2.deposit(1000.0);
		System.out.println("Account 3 = " + acct3.toString());

		// acct2 will have changed, because acct2 and acct3 both reference
		// the same object.
		System.out.println("Account 2 = " + acct2.toString());
		
		//System.out.println("acct1 balance is " + acct1.balance);
		//System.out.println("acct2 balance is " + acct2.getBalance());
		System.out.println(acct1.toString());
		System.out.println(acct2);
		
		CheckingAccount checking1 = new CheckingAccount();
		checking1.setAccountNo(7636633);
		checking1.deposit(1000);
		checking1.setOverdraftProtection(true);
		System.out.println("Checking accounts:");
		System.out.println(checking1.toString());

		CheckingAccount checking2 = 
				new CheckingAccount(2000, 199838, false);
		System.out.println(checking2.toString());
		
		
		// setup an array of Accounts, and display them using the
		// toString method.  Can you say polymorphism?
		Account[] accounts = new Account[3];
		accounts[0] = acct1;
		accounts[1] = acct2;
		accounts[2] = checking1;
		
		System.out.println("Processing list polymorphically...");
		for (Account a : accounts) {
			System.out.println(a.toString());
		}
	
	}

}
