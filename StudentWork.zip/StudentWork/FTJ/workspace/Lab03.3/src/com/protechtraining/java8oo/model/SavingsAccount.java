package com.protechtraining.java8oo.model;

public class SavingsAccount extends Account {
	private static double interestRate;

	public SavingsAccount() {
		super();
	}
	public SavingsAccount(double balance, int accountNo) {
		super(balance, accountNo);
	}
	public SavingsAccount(int accountNo) {
		super(accountNo);
	}
	
	public static double getInterestRate() {
		return interestRate;
	}
	public static void setInterestRate(double interestRate) {
		SavingsAccount.interestRate = interestRate;
	}
	
	public double calculateInterest() {
		return balance * SavingsAccount.interestRate;
	}
	@Override
	public String toString() {
		return super.toString() + ", Interest rate = " +
				SavingsAccount.interestRate;
	}
	
	
}
