package com.protechtraining.java8oo.model;

// sets up an inheritance relationshipt
// Account is the superclass
// CheckingAccount is the subclass
public class CheckingAccount extends Account {
	private boolean overdraftProtection;

	public CheckingAccount() {
		super();
		this.overdraftProtection = true;
	}

	public CheckingAccount(double balance, int accountNo, 
			boolean overdraftProtection) {
		super(balance, accountNo);
		this.overdraftProtection = overdraftProtection;
	}

	public CheckingAccount(int accountNo) {
		super(accountNo);
	}
	
	public boolean isOverdraftProtection() {
		return overdraftProtection;
	}

	public void setOverdraftProtection(boolean overdraftProtection) {
		this.overdraftProtection = overdraftProtection;
	}

	// annotation
	@Override
	public String toString() {
		return super.toString() + ", CheckingAccount [overdraftProtection=" + overdraftProtection + "]";
	}
	
	
	
}
