package com.protechtraining.java8oo;

import com.protech.io.ConsoleHelper;

public class IfStatementsAndEquals {
	public static void main(String[] args) {
		int score;

		score = ConsoleHelper.readInt("Enter a score: ");

		// check for an invalid score
		// || means or in Java. && means and in Java.
		if (score < 0 || score > 100) {
			System.out.println("Invalid score.");
		} else {
			// == compares, while a single = assigns (changes)
			if (score == 100) { 
 				System.out.println("Pass - perfect score.");
			} else if (score >= 60) {
				System.out.println("Pass");
				System.out.println("Good job");
			 } else { 
				System.out.println("Fail");
			 }
		}
		
		String name1;
		name1 = ConsoleHelper.readLine("Enter a name: ");
		
		String name2;
		name2 = ConsoleHelper.readLine("Enter another name: ");

		// With objects in Java, == only compares the references, so
		// using == below will not work, even if the names entered
		// are the same.  Use .equals to compared the actual contents
		// of the objects (the characters themselves, not the pointer)
		//if (name1 == name2) {
		if (name1.equals(name2)) {
			System.out.println("Names match.");
		} else {
			System.out.println("Names don't match.");
		}
		
	} // end main
} // end class
