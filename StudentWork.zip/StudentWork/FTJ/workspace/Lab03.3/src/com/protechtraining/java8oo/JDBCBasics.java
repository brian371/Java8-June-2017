package com.protechtraining.java8oo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCBasics {
	public static void main(String[] args) {
		try {
			DriverManager.registerDriver(new org.apache.derby.jdbc.ClientDriver());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		try (Connection conn = DriverManager.getConnection(
				"jdbc:derby://localhost:1527/JavaTunesDB",
				"guest", "password")) {
			
			String sql = "SELECT ITEM_ID, Title, Price FROM Item";
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				long id = rs.getLong("ITEM_ID");
				String title = rs.getString("Title");
				double price = rs.getDouble("price");
				System.out.println("id = " + id + 
						", title = " + title + ", price = " + price);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
