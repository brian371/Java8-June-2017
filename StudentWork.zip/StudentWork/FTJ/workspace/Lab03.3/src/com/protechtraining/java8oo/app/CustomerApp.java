package com.protechtraining.java8oo.app;

import com.protechtraining.java8oo.model.Account;
import com.protechtraining.java8oo.model.Customer;

public class CustomerApp {
	public static void main(String[] args) {
		// This application demonstrates composition.
		Customer c1 = new Customer();
		// fill in the customer objectd
		c1.setCustomerNum(13831);
		c1.setFirstName("Bob");
		c1.setLastName("Smith");
		
		Account savings = new Account();
		c1.setSavings(savings);
		c1.getSavings().setAccountNo(83833);
		c1.getSavings().deposit(1000);
		
		// create a checking account for Bob
		Account checking = new Account();
		checking.setAccountNo(120292);
		checking.deposit(20);
		c1.setChecking(checking);
		
		c1.transferFromSavings(200); // example of delegation
		
		System.out.println(c1.toString());
		
	}
}
