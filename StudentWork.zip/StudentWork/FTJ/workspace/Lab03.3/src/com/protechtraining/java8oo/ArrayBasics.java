package com.protechtraining.java8oo;

import com.protechtraining.java8oo.model.Account;

public class ArrayBasics {
	public static void main(String[] args) {
		/*String[] daysInWeek = new String[7];
		daysInWeek[0] = "Sunday";
		daysInWeek[1] = "Monday";
		daysInWeek[2] = "Tuesday";
		daysInWeek[3] = "Wednesday";
		daysInWeek[4] = "Thursday";
		daysInWeek[5] = "Friday";
		daysInWeek[6] = "Saturday";*/
		
		// same thing but much shorter
		String[] daysInWeek = {"Sunday", "Monday", "Tuesday",
				"Wednesday", "Thursday", "Friday", "Saturday"};
		System.out.println("The first day of the week is " + daysInWeek[0]);
		
		// display all the days in the week - long way
		for (int i = 0; i < daysInWeek.length; i++) {
			System.out.println(daysInWeek[i]);
		}
		
		// shorter to use the for each loop in Java
		for (String day : daysInWeek) {
			System.out.println(day);
		}
		
		
		// create an array of Account references
		Account[] accounts = new Account[3];
		// how many account objects are there?  There are 0!
		System.out.println(accounts[0]);  // prints out null - no object
		accounts[0] = new Account(); // now I have 1 Account object
		accounts[0].setAccountNo(73733);
		accounts[0].deposit(200);
		
		//Account acct1 = new Account();
		
		// There are names passed into the program in String[] args
		if (args.length == 0 ) {
			System.out.println("There are no names.");
		} else {
			String[] names = new String[args.length];
			for(int i = 0; i< args.length; i++) {
				//System.out.println(args[i]);
				names[i] = args[i];
			}
			// names has all of the names sent in from the command line (args)
		}
		
		
		String server = System.getProperty("server");
		System.out.println("The server is " + server);
		
		
	}
}
