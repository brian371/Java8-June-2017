package com.protechtraining.java8oo;

import com.protech.io.ConsoleHelper;

public class StringBasics {
	private StringBuffer buffer;
	
	public static void main(String[] args) {
		String fullName = ConsoleHelper.readLine(
				"Enter your first and name, seperated by a space: ");
		
		int spacePos = fullName.indexOf(" ");
		if (spacePos == -1) {
			System.out.println("You must enter a first and "
					+ "last name seperated by a space");
			System.exit(-1);
		}
		
		System.out.println("spacePos=" + spacePos);
		String firstName = fullName.substring(0, spacePos).trim();
		System.out.println("First Name is " + firstName);
		
		// extract lastName and print out
		String lastName = fullName.substring(spacePos + 1).trim();
		System.out.println("Last Name is " + lastName);
		
		String suffix = "jr.";
		
		// this is bad because of all the objects created through
		// concatenation...
		String junior = firstName;
		junior = junior + " " + lastName;
		junior = junior +  "jr.";
		System.out.println(junior);
		
		// single StringBuffer/StringBuilder.  This stops the proliferation
		// of String objects
		StringBuilder juniorBuilder = new StringBuilder();
		juniorBuilder.append(firstName);
		juniorBuilder.append(" ");
		juniorBuilder.append(lastName);
		juniorBuilder.append(" jr");
		junior = juniorBuilder.toString();
		System.out.println(junior);
		
		// java has support for regular expressions.
		// It has a weird hodpodge of posix and perl
		String pattern = "[0-9]{3}-[0-9]{2}-[0-9]{4}";
		if (!"444-44-444".matches(pattern)) {
			System.out.println("Bad ssn");
		}
		
	} // end main
} // end class
