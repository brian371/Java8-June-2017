package com.protechtraining.java8oo.model;

import java.text.NumberFormat;

public class Account {
	// attribute
	protected double balance;
	private int accountNo;
	private String accountCode;
	
	public String getAccountCode() {
		return accountCode;
	}
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	// constructor
	public Account() {
		this(1.0, 0);
		System.out.println("Inside constructor...");
	}
	public Account(int accountNo) {
		this(1.0, accountNo);
	}
	// overloaded constructor
	public Account(double balance, int accountNo) {
		super();
		this.balance = balance;
		setAccountNo(accountNo);
	}

	// getters and setters
	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return balance;
	}

	// business methods
	public void deposit(double amount) {
		this.balance = this.balance + amount;
	}

	// deposit method is overloaded.
	public void deposit(double amount, String comment) {
		balance = balance + amount;
		// comment is logged somewhere.
	}
	
	public void withdraw(double amount) {
		// local variable
		double temporaryBalance = balance - amount;
		if (temporaryBalance < 0) {
			// check overdraft protection...
		}
		balance = temporaryBalance;
	}


	@Override
	public String toString() {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		return "Account [balance=" + nf.format(balance) + 
				", accountNo=" + accountNo + "]";
	}

	
	
		
} // end class